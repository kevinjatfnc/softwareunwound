﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using CDNASDK;

namespace QuadTreeExample
{
    /// <summary>
    /// Simple quadtree demonstration in C# - based on the wikipedia article @
    /// http://en.wikipedia.org/wiki/Quadtree
    //
    // - kj  2014
    /// </summary>
    /// 
    class Program
    {
        const int QuadTreeSize = 1024;
        
        static void Main(string[] args)
        {
            //Create the quadtree instance
            QuadTree qt = new QuadTree(new Rectangle(0, 0, QuadTreeSize, QuadTreeSize));
            Console.Write("Quad tree created: {0} X {1}.\r\n\r\n", qt.BoundingBox.Width, qt.BoundingBox.Height);
            /*
            0,0----------------------------------------------------QuadTreeSize
             |                                                                 |
             |                                                                 |
             |                                                                 |
             |                                                                 |
             |                                                                 |
             |                                                                 |
             |                                                                 |
             |                                                                 | 
             |                                                                 |
             |                                                                 |
             |                                                                 |
             |                                                                 |
             |                                                                 |
             |                                                                 |
             |                                                                 |
             QuadTreeSize-------------------------------------------QuadTreeSize
            */
            

            #region Stopwatch
            // Create new stopwatch
            Stopwatch stopwatch = new Stopwatch();

            // Begin timing
            stopwatch.Start();
            #endregion

            #region Insert 1M objects into the quadtree
            //a list to hold our test data
            List<TestData> tdl = new List<TestData>();
            //insert 1M random locations
            int s;
            Console.Write("Inserting 1M records into the quadtree");
            Random random = new Random();
            for (s=0; s < 1000000; s++)
            {
                //create a new object of type Testdata
                TestData td = new TestData();
                
                //create a random point 
               
                int X = random.Next(0, QuadTreeSize);
                int Y = random.Next(0, QuadTreeSize);



                Array values = Enum.GetValues(typeof(TestData.SomeData));

                //add some meaningful data
                td.somedata = (TestData.SomeData)values.GetValue(random.Next(values.Length));
                td.xy = new Point(X, Y);
    
                //Add to our list
                tdl.Add(td);
                //insert the testdata object into the quadtree for brute force test
                qt.insert(td);          
          
            }
            // Stop timing
            stopwatch.Stop();

            // Write result
            Console.Write(" in {0} ms.\r\n\r\n",
                stopwatch.Elapsed.Milliseconds);
            #endregion

            // Define Viewport - viewport location is in quadtree space (X, Y, Width,Height)
            Rectangle Viewport = new Rectangle(632, 286, 104,113);
            Console.Write("Viewport is located at {0},{1} and is {2} X {3}.\r\n\r\n",Viewport.X,Viewport.Y,Viewport.Width,Viewport.Height);

           //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
           // Parsing the Viewport - Return all rows in Viewport rectangle using brute force array parsing (for loop)
           // Return all records with an .XY in the current viewport and .somedata is either "BA","BD","AA" or "BB" 

           #region Brute force array parsing
           int recordcount;
           // Begin timing
           stopwatch = new Stopwatch();
           stopwatch.Start();
           recordcount = 0;
           //Brute Force Method:
           foreach( TestData td in tdl)
           {
               //add in some random computational logic (ToString() is suppose to be slow so i use it as an example)
               if ((td.somedata.ToString().Equals("BA") || td.somedata.ToString().Equals("BD")
                   || td.somedata.ToString().Equals("AA")
                   || td.somedata.ToString().Equals("BB"))
                   && Viewport.Contains(td.xy)) recordcount++;
               
           }
           // Stop timing
           stopwatch.Stop();

           // Write result
           Console.Write("Brute force array parsing:\n\r{0} records matching criteria in {1} ms.\r\n\r\n",recordcount,
               stopwatch.Elapsed.Milliseconds);
           #endregion

           //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
           // Parsing the Viewport - Return all rows in Viewport rectangle using brute force array parsing (for loop)
           // Return all records with an .XY in the current viewport and .somedata is either "BA","BD","AA" or "BB" 

           #region Brute force array parsing w/ viewport clipping
           // Begin timing
           stopwatch = new Stopwatch();
           stopwatch.Start();
           recordcount = 0;
           //Brute Force Method:
           foreach (TestData td in tdl)
           {
               //early out test - clip to the viewport
               if (Viewport.Contains(td.xy))
                   //add in some random computational logic (ToString() is suppose to be slow so i use it as an example)
                   if (td.somedata.ToString().Equals("BA") || td.somedata.ToString().Equals("BD")
                       || td.somedata.ToString().Equals("AA")
                       || td.somedata.ToString().Equals("BB")) recordcount++;

           }
           // Stop timing
           stopwatch.Stop();

           // Write result
           Console.Write("Brute force with viewport clipping:\n\r{0} records matching criteria in {1} ms.\r\n\r\n", recordcount,
               stopwatch.Elapsed.Milliseconds);
           #endregion

           //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
           // Parsing the Viewport - Return all rows in Viewport rectangle using quadtree range queries
           // Return all records with an .XY in the current viewport and .somedata is either "BA","BD","AA" or "BB" 

           #region Parse using quadtree
           // Begin timing
           stopwatch = new Stopwatch();
           stopwatch.Start();

           recordcount = 0;
           foreach( TestData td in qt.queryRange(Viewport))
           {
               //add in some random computational logic (ToString() is suppose to be slow so i use it as an example)
               if (td.somedata.ToString().Equals("BA") || td.somedata.ToString().Equals("BD")
                   || td.somedata.ToString().Equals("AA")
                   || td.somedata.ToString().Equals("BB")) recordcount++;
               
           }
           // Stop timing
           stopwatch.Stop();

           // Write result
           Console.Write("Quadtree method:\r\n{0} records matching criteria in {1} ms.\r\n",recordcount,
               stopwatch.Elapsed.Milliseconds);
           #endregion


           Console.ReadLine();
        }
    }
}
