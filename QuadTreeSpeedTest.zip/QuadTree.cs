﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Drawing;


namespace CDNASDK
{
    /// <summary>
    /// Simple Quadtree class in C# - based on the wikipedia article @
    /// http://en.wikipedia.org/wiki/Quadtree
    //
    // - kj  2014
    /// </summary>
    
    #region Test Data Model

    public class TestData
    {
       public  enum SomeData
        {
            AA,
            AB,
            AC,
            AD,
            AE,
            AF,
            BA,
            BB,
            BC,
            BD,
            BE,
            BF
        };


        public Point xy { get; set; }
        public SomeData somedata { get; set; }
    
    }
    #endregion


    public partial class QuadTree
    {
      // Arbitrary constant to indicate how many elements can be stored in this quad tree node
      // one place to tune performance is by tuning the node capacity
      const int QT_NODE_CAPACITY = 25;
      // Axis-aligned bounding box stored as a center with half-dimensions or a rectangle in 2D ;P
      // to represent the boundaries of this quad tree
      public Rectangle BoundingBox;
 
 
      // Any class with a Point type property can be used here
      List<TestData> points = new List<TestData>();
 
      
      // Children
      public QuadTree northWest;
      public QuadTree northEast;
      public QuadTree southWest;
      public QuadTree southEast;
      // Methods
      public QuadTree(Rectangle _boundingBox )
      {
          BoundingBox = _boundingBox;
          northWest = null;
          northEast = null;
          southWest = null;
          southEast = null;
           
      }
      // Insert a point into the QuadTree
      public bool insert(TestData p)
      {
          // Ignore objects which do not belong in this quad tree
          if (!BoundingBox.Contains(p.xy))
              return false; // object cannot be added
          if (points == null) points = new List<TestData>();
          // If there is space in this quad tree, add the object here
          if (points.Count < QT_NODE_CAPACITY)
          {
              points.Add(p);         
              return true;
          }
          // Otherwise, we need to subdivide then add the point to whichever node will accept it
          if (northWest == null)
              subdivide();
          //looks like the order here matters...
          if (northWest.insert(p)) return true;
          if (southWest.insert(p)) return true;
          if (southEast.insert(p)) return true;
          if (northEast.insert(p)) return true;
 
          // Otherwise, the point cannot be inserted for some unknown reason (which should never happen)
          return false;
      }
     
      private void subdivide()
      {
          // create four children which fully divide this quad into four quads of equal area
          Rectangle BBNW = new Rectangle(BoundingBox.X, BoundingBox.Y, BoundingBox.Width / 2, BoundingBox.Height / 2);
           
          Rectangle BBNE = new Rectangle(BoundingBox.X + BoundingBox.Width / 2,
                                BoundingBox.Y, BoundingBox.Width / 2, BoundingBox.Height / 2);
          Rectangle BBSW = new Rectangle(BoundingBox.X,
                                BoundingBox.Y + BoundingBox.Height /2, BoundingBox.Width / 2, BoundingBox.Height / 2);
 
          Rectangle BBSE = new Rectangle(BoundingBox.X + BoundingBox.Width / 2,
                                BoundingBox.Y  + BoundingBox.Height /2, BoundingBox.Width / 2, BoundingBox.Height / 2);
           
         // create the new quad trees
          northWest = new QuadTree(BBNW);      
          northEast = new QuadTree(BBNE);
          southWest = new QuadTree(BBSW);
          southEast = new QuadTree(BBSE);
          
         
         // insert points contained in northwest bounding box
         foreach(TestData p in queryRange(BBNW))
         {
               northWest.insert(p);
         }
         // insert points contained in southwest bounding box
         foreach (TestData p in queryRange(BBSW))
         {
             southWest.insert(p);
         }
         // insert points contained in southeast bounding box
         foreach (TestData p in queryRange(BBSE))
         {
             southEast.insert(p);
         }
         // insert points contained in northeast bounding box
         foreach (TestData p in queryRange(BBNE))    
         {
             northEast.insert(p);
         }
        //since the points are now in children quads
        //clear the list
        points.Clear();
         
      }
 
      public TestData[] queryRange(Rectangle range)
      {
          // Prepare an array of results
          List<TestData> pointsInRange = new List<TestData>();
          // Automatically abort if the range does not collide with this quad
          if (!BoundingBox.IntersectsWith(range))
            return pointsInRange.ToArray(); // empty list
          if (points == null) points = new List<TestData>();
          // Check objects at this quad level
          for (int p = 0; p < points.Count ; p++)
          {
             if (range.Contains(points[p].xy))
                pointsInRange.Add(points[p]);
          }
          // Terminate here, if there are no children
          if (northWest == null)
              return pointsInRange.ToArray();
          // Otherwise, add the points from the children
          pointsInRange.AddRange(northWest.queryRange(range));
          pointsInRange.AddRange(southWest.queryRange(range));
          pointsInRange.AddRange(southEast.queryRange(range));
          pointsInRange.AddRange(northEast.queryRange(range));
          return pointsInRange.ToArray();
      }
   }
}
 